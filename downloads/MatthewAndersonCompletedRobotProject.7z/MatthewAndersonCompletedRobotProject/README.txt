---------------------------------------------------------------------------------------------------
What works:

-- Serial port communications work.
-- Moves Rhino to a specified point.
-- Circle class makes a highly accurate circle.
-- Line class makes a straight line point to point.
-- Utilizes inheritance and polymorphism, as well as aggregation/composition.

---------------------------------------------------------------------------------------------------
Stuff I wish it had but doesn't:
-- IBM 7535 specific code (ran out of time, I had some but decided to remove it, as was incomplete.)

-- A GUI interface.