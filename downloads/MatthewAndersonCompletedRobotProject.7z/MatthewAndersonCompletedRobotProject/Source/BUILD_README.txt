Requires at least CMake 2.9 to be installed to build the source.

I reduced the required version from 3.6.0 to 2.9.0 in this release.
You can obtain CMake here: https://cmake.org/download/