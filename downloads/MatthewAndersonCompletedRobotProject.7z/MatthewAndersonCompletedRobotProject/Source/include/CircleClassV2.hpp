//
//  @ Project : MattsRoboCode
//  @ File Name : CircleClassV2.hpp
//  @ Date : 5/19/2017
//  @ Author : Matthew R. Anderson
//
//


#ifndef CIRCLECLASSV2_H
#define CIRCLECLASSV2_H

#include "MathClass.hpp"

class CircleClassV2 : public MathClass {
public:
    void setRadius(long double radius);
    void computeDT(long double startAngle, long double endAngle);
    Values* getXY(int step, long double startAngle);
    void setCenterpoint(Values* startingPoint);
    float getNumberSegments();
private:
    long double radius;
    long double deltaTheata;
    long double segment = 0.05;
    float numSegments;
    long double centerpointX;
    long double centerpointY;
};

#endif
