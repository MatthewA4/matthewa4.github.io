//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

#pragma once
#include <string>
#include <fstream>
#include <vector>
#include <iostream>
#include "MathClass.hpp"

//bit fields
#define COORD_ABSOLUTE (1 << 1)	//Absolute Coordinate Mode
#define COORD_INCREMENTAL (1 << 2)	//Incremental Coordinate Mode
#define MILLIMETERS (1 << 3)
#define INCHES (1 << 4)
#define EOF_COMMAND_REACHED (1 << 5)
#define CAN_MOVE (1 << 7)
#define RAPID_MOVE (1 << 8)
#define LINEAR_CUTTING_MOVE (1 << 9)
#define GO_HOME (1 << 11)
#define ENGRAVE_ON (1 << 12)
#define ENGRAVE_OFF (1 << 13)

class GCodeParser
{
	private:
		std::vector<std::string> GCodeVector;
		long long				numberOfInstructions;
		std::ifstream	File;
		Values*			XY;
		int				feedspeed;
		void			G_00_(std::string tempString);
		void			G_01_(std::string tempString);
		void			G_80_();
		void			G_81_(std::string tempString);
		long			OperationModes;
	public:
		GCodeParser(){};
		~GCodeParser(){ File.close(); };
		
		long long		getNumberInstructions() { return numberOfInstructions; }
		void			getCommand(long long step);
		int				getFeedSpeed() { return feedspeed; }
		std::string		getOperationStatus();
		long			getOperationMode();
		void			setFile(char* name, Values* endPoint);
};
