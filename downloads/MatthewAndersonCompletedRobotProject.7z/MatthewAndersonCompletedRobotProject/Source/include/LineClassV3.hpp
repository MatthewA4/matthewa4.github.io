//
//  @ Project : MattsRoboCode
//  @ File Name : LineClassV3.hpp
//  @ Date : 5/18/2017
//  @ Author : Matthew R. Anderson
//


#if !defined(_LINECLASSV3_H)
#define _LINECLASSV3_H

#include "MathClass.hpp"

class LineClassV3 : public MathClass {
public:
    Values* getXY(Values* startPoint, long long step);
	long double getLength() { return Length; };
    void setLength(Values* startPoint, Values* endPoint);
	long double getNumSegments() { return numsegments; };
	void findslope();
private:
    long double Length;
    long long howfaralong;
    long double numsegments;
    long double segment = 0.01;
    long double deltaX;
    long double deltaY;
    long double SlopeX;
    long double SlopeY;
};

#endif  //_LINECLASSV3_H
