//******************************************************
//	Copyright (C) 2017 Matthew R. Anderson
//	All Rights Reserved.	

//	Department: COMSC11 C++ Programming Department
//
//	Fulfills Math Class assignment.

//	Revision History:
//		2/20/2017 last revision -- Matthew R. Anderson
//
//******************************************************

#pragma once
#define _USE_MATH_DEFINES
#include <cmath>

struct Values {
	
		long double		x, y, r, T1, T2;
};

class MathClass {
	
	private:
		long double		LengthArm1, LengthArm2;
		
		void			computeT1			(long double &x, long double &y);
		void			computeT2			(long double &x, long double &y);
		long double		theata1, theata2;

	public:
		
		MathClass				(long double L1, long double L2);
		MathClass()				{};
		~MathClass				() {};
		void					compute(long double x, long double y);
		long double				getT1();
		long double				getT2();
		template<class value> static value roundingFunction
								(value theValue);
};