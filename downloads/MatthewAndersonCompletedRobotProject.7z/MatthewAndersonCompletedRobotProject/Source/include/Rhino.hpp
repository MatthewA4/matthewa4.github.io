//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

//COMSC11 Robot Project

#pragma once
#include <cmath>
#include "tserial.h"
#include "MathClass.hpp"
#include <cstdlib>
#include <iostream>
#include <string>
#include "RoboBase.hpp"

class Rhino : public RoboBase {

private:
	Tserial					*theConnection;
	MathClass				*theMath;
	char*					Port;
	bool					isEngraving = false;
	static long				DMotorClickCount, EMotorClickCount;
	static long				DMotorPreviousCount, EMotorPreviousCount;
	char					getSwitchPosStatus(char sendChar);
	char					getMotorPosStatus(const char Motor);
	void					wait(char motor);
public:
				
				//Use this constructor for regular Rhino robot usage
				Rhino					(Tserial *serial, MathClass *theMath, char* Port) {
										theConnection = serial;
										this->theMath = theMath;
										this->Port = Port;
										setName("Rhino");
										};

				~Rhino					(){};
	void		Move					(long double x, long double y, long double r = 0.0);
	void		goHome					();
	void		EngraveOn				();
	void		EngraveOff				();
};