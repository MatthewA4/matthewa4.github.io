//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.
#pragma once
#include <string>
#include "MathClass.hpp"
#include "LineClassV3.hpp"
#include "CircleClassV2.hpp"
#include "GCodeParser.h"

class RoboBase : private GCodeParser {

private: 
	std::string RobotName;
	long long numberOfMovements = 0;
public:
	virtual void Move(long double x, long double y, long double r = 0) = 0;
	virtual void goHome() = 0;
	void DrawImage(char* filename, Values* Current, Values* startPoint);
	virtual void CircleMove(long double radius, Values* startPoint, long double arcAngle);
	virtual void LineMove(Values* startPoint, Values* endPoint);
	virtual void EngraveOn() = 0;
	virtual void EngraveOff() = 0;
	std::string getName() { return RobotName; };
	void incNumMovements(int howmuch) { numberOfMovements += howmuch; };
	long long getNumMovements() { return numberOfMovements; }
protected:
	void setName(std::string name) { this->RobotName = name; };
	void setName(char* name) { this->RobotName = name; };
};
