//
//  @ Project : MattsRoboCode
//  @ File Name : CircleClassV2.cpp
//  @ Date : 5/19/2017
//  @ Author : Matthew R. Anderson
//
//
#include "CircleClassV2.hpp"

void CircleClassV2::setRadius(long double radius) {
	this->radius = radius;
}

void CircleClassV2::computeDT(long double startAngle, long double endAngle) {
	deltaTheata = (endAngle - startAngle) * (M_PI / 180);	//convert to radians
	numSegments = deltaTheata / segment;
}

Values* CircleClassV2::getXY(int step, long double startAngle) {
	long double MoveAngle = startAngle + (step*segment);
	Values *ret = new Values;
	ret->x = centerpointX + radius*cos(MoveAngle);
	ret->y = centerpointY + radius*sin(MoveAngle);
	return ret;
}

void CircleClassV2::setCenterpoint(Values* startingPoint) {
	centerpointX = startingPoint->x - radius;
	centerpointY = startingPoint->y;
}

float CircleClassV2::getNumberSegments() {
	return numSegments;
}