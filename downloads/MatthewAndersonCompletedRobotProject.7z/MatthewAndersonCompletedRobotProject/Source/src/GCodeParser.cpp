//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

#include "GCodeParser.h"
using namespace std;

void			GCodeParser::setFile(char* name, Values* endPoint)
{
	this->XY = endPoint;
	OperationModes = 0;
	feedspeed = 15;
	File.open(name);
	File.seekg(0, std::ios::end);
	std::string tempString;
	File.seekg(0, std::ios::beg);
	while (File.get() != EOF)
	{
		File.unget();
		getline(File, tempString);
		GCodeVector.push_back(tempString);
	}
	numberOfInstructions = GCodeVector.size();
}

std::string GCodeParser::getOperationStatus()
{
	string status;
	status.append("*************************************\n");
	status.append("\t\tStatus\n");
	status.append("*************************************\n\n");
	
	if (OperationModes != 0)
	{
		if ((OperationModes & EOF_COMMAND_REACHED) != 0)
		{
			return "\0";
		}

		 if ((OperationModes & COORD_ABSOLUTE) != 0)
			status.append("Absolute Positioning Enabled\n");
		else if ((OperationModes & COORD_INCREMENTAL) != 0)
			status.append("Incremental Positioning Enabled\n");
		 status.append("FEEDSPEED:\t");

		char feed[16] = { 0, };
		status.append(itoa(feedspeed, feed, 10));

		if ((OperationModes & ENGRAVE_ON) != 0)
			status.append("\nENGRAVING...\n");
		else status.append("\nNOT ENGRAVING...");

		status.append("\n\n");
		status.append("*************************************\n");
	}
	else
	{
		return "\0";
	}
	return status;
}

long			GCodeParser::getOperationMode()
{
	return OperationModes;
}

void			GCodeParser::getCommand(long long step)
{
	if ((OperationModes & EOF_COMMAND_REACHED) == 0)
	{
		std::string tempString;
		tempString = GCodeVector[step - 1];
		
		//Default to inches
		if ((OperationModes & MILLIMETERS) == 0) OperationModes |= INCHES;


		//Disable all movement modes if they are enabled.
		if ((OperationModes & GO_HOME) != 0) OperationModes &= ~GO_HOME;
		if ((OperationModes & CAN_MOVE) != 0) OperationModes &= ~CAN_MOVE;	//If the flag is set for movement, flip it off.
		if (OperationModes & LINEAR_CUTTING_MOVE) OperationModes &= ~LINEAR_CUTTING_MOVE;
		if (OperationModes & RAPID_MOVE) OperationModes &= ~RAPID_MOVE;

		//Pause
		if (tempString.find("M0") != string::npos)
		{
			system("pause");

		}

		//Sets feed speed.
		else if (int Temp = tempString.find("F") != string::npos)
		{
			string string2;
			string2 = tempString.substr(Temp);
			feedspeed = atoi(string2.c_str());
		}


		else if (int Temp = tempString.find("G4 ") != string::npos)
		{
			string secondString;
			secondString = tempString.substr(Temp + 2);
			int amountOfSleep = atoi(secondString.c_str());
			cout << "DWELL:\t" << amountOfSleep << endl;
			_sleep(amountOfSleep * 1000);
		}

		else if (int Temp = tempString.find("G4/") != string::npos)
		{
			string secondString;
			secondString = tempString.substr(Temp + 2);
			int amountOfSleep = atoi(secondString.c_str());
			cout << "DWELL:\t" << amountOfSleep << endl;
			_sleep(amountOfSleep * 1000);
		}

		else if (tempString.find("M30") != string::npos)
		{
			OperationModes |= EOF_COMMAND_REACHED;
		}

		//Set Millimeters measurement
		else if (tempString.find("G21") != string::npos)
		{
			OperationModes |= MILLIMETERS;
			if ((OperationModes & INCHES) != 0) OperationModes &= ~INCHES;
		}

		else if (tempString.find("G20") != string::npos)
		{
			OperationModes |= INCHES;
			if ((OperationModes & MILLIMETERS) != 0) OperationModes &= ~MILLIMETERS;
		}

		//Set Absolute Coordinate
		else if (tempString.find("G90") != string::npos)
		{
			OperationModes |= COORD_ABSOLUTE;
			if(OperationModes & COORD_INCREMENTAL) OperationModes &= ~COORD_INCREMENTAL;
		}

		//Set Incremental Coordinate
		else if (tempString.find("G91") != string::npos)
		{
			OperationModes |= COORD_INCREMENTAL;
			if(OperationModes & COORD_ABSOLUTE) OperationModes &= ~COORD_ABSOLUTE;
		}

		//Incremental Move
		else if (tempString.find("G01") != string::npos)
		{
			OperationModes |= LINEAR_CUTTING_MOVE;
			if ((OperationModes & RAPID_MOVE) != 0) OperationModes &= ~RAPID_MOVE;
			G_01_(tempString);
		}

		//Absolute Move
		else if (tempString.find("G00") != string::npos)
		{
			OperationModes |= RAPID_MOVE;
			if ((OperationModes & LINEAR_CUTTING_MOVE) != 0) OperationModes &= ~LINEAR_CUTTING_MOVE;
			G_00_(tempString);
		}

		else if (tempString.find("G0") != string::npos)
		{
			OperationModes |= RAPID_MOVE;
			if ((OperationModes & LINEAR_CUTTING_MOVE) != 0) OperationModes &= ~LINEAR_CUTTING_MOVE;
			G_00_(tempString);
		}

		else if (tempString.find("G1") != string::npos)
		{
			OperationModes |= LINEAR_CUTTING_MOVE;
			if ((OperationModes & RAPID_MOVE) != 0) OperationModes &= ~RAPID_MOVE;
			G_01_(tempString);
		}

		//Homing, needs to be first, as G2 is first in the next two
		else if (tempString.find("G28") != string::npos)
		{
			OperationModes |= CAN_MOVE;
			OperationModes |= GO_HOME;
		}

		else if (tempString.find("G80") != string::npos)
		{
			G_80_();
		}
		
		else if (tempString.find("G81") != string::npos)
		{
			G_81_(tempString);
		}

	}
}

void			GCodeParser::G_00_(std::string tempString)
{
	std::string XString, YString, ZString;
	int Xpos, Ypos, Zpos = 0;
	if ((Xpos = tempString.find("X")) != string::npos)
	{
		int EndPos;
		EndPos = tempString.find("Y", Xpos);
		XString = tempString.substr(Xpos + 1, EndPos - (Xpos + 1));
	}
	if ((Ypos = tempString.find("Y")) != string::npos)
	{
		int EndPos;
		EndPos = tempString.find("Z", Zpos);
		YString = tempString.substr(Ypos + 1, EndPos - (Zpos + 1));
	}
	if ((Zpos = tempString.find("Z")) != string::npos)
	{
		ZString = tempString.substr(Zpos + 1);
	}
	//If AbsoluteMove
	if ((OperationModes & COORD_ABSOLUTE) != 0)
	{
		OperationModes |= CAN_MOVE;				//Give it clearance to move
		this->XY->x = atof(XString.c_str());
		this->XY->y = atof(YString.c_str());
		this->XY->r = atof(ZString.c_str());
		if ((OperationModes & MILLIMETERS) != 0)
		{
			XY->x *= 0.0393701;
			XY->y *= 0.0393701;
			XY->r *= 0.0393701;
		}
	}
	
	//If incremental move
	else if ((OperationModes & COORD_INCREMENTAL) != 0)
	{
		OperationModes |= CAN_MOVE;			   //Give it clearance to move
		this->XY->x += atof(XString.c_str());
		this->XY->y += atof(YString.c_str());
		this->XY->r += atof(ZString.c_str());
		if ((OperationModes & MILLIMETERS) != 0)
		{
			XY->x *= 0.0393701;
			XY->y *= 0.0393701;
			XY->r *= 0.0393701;
		}
	}
}

void			GCodeParser::G_01_(std::string tempString)
{
	G_00_(tempString);
}

void			GCodeParser::G_80_()
{
	if ((OperationModes & ENGRAVE_ON) != 0) OperationModes &= ~ENGRAVE_ON;
	OperationModes |= ENGRAVE_OFF;
	OperationModes |= CAN_MOVE;
	if (OperationModes & LINEAR_CUTTING_MOVE) OperationModes &= ~LINEAR_CUTTING_MOVE;
	if (OperationModes & RAPID_MOVE) OperationModes &= ~RAPID_MOVE;
}

void			GCodeParser::G_81_(std::string tempString)
{
	OperationModes |= ENGRAVE_ON;
	if ((OperationModes & ENGRAVE_OFF) != 0) OperationModes &= ~ENGRAVE_OFF;
	OperationModes |= CAN_MOVE;
	if (OperationModes & LINEAR_CUTTING_MOVE) OperationModes &= ~LINEAR_CUTTING_MOVE;
	if (OperationModes & RAPID_MOVE) OperationModes &= ~RAPID_MOVE;
}