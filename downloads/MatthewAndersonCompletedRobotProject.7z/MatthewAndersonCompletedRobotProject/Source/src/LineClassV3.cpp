//
//  @ Project : MattsRoboCode
//  @ File Name : LineClassV3.cpp
//  @ Date : 5/18/2017
//  @ Author : Matthew R. Anderson
//
#include "LineClassV3.hpp"

Values* LineClassV3::getXY(Values* startPoint, long long step) {
	Values *ret = new Values;
	ret->x = startPoint->x + (SlopeX*step*segment);
	ret->y = startPoint->y + (SlopeY*step*segment);
	return ret;
}

void LineClassV3::setLength(Values* startPoint, Values* endPoint) {
	deltaX = (endPoint->x - startPoint->x);
	deltaY = (endPoint->y - startPoint->y);

	Length = sqrt(
		pow(deltaX, 2.0) + pow(deltaY, 2.0)
	);
	numsegments = (Length / segment);
}

void LineClassV3::findslope() {
	SlopeX = deltaX / Length;
	SlopeY = deltaY / Length;
}