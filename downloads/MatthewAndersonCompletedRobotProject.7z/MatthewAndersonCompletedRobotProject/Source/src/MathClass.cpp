//******************************************************
//	Copyright (C) 2017 Matthew R. Anderson
//	All Rights Reserved.	

//	Department: COMSC11 C++ Programming Department
//
//	Fulfills Math Class assignment.

#include "MathClass.hpp"
#include <iostream>
using namespace std;

			MathClass::MathClass
(long double L1, long double L2) 
: LengthArm1(L1), LengthArm2(L2)
			{}


void		MathClass::compute
(long double x, long double y){
				computeT2		(x, y);
				computeT1		(x, y);
				//convert to degrees
				theata1 *= (180.0 / M_PI);
				theata2 *= (180.0 / M_PI);
				//Round it to two decimal places...
				theata1	=	roundingFunction	(theata1);
				theata2	=	roundingFunction	(theata2);
}

long double	MathClass::getT1
() 
{
	return theata1;
}

long double MathClass::getT2
() {
	return theata2;
}

template <class value>	
value	static	MathClass::roundingFunction
(value theValue) {
				
				value tempTheValue = theValue;
				int TempInt = 0;
				tempTheValue *= 10000.0;
				TempInt = static_cast<int>(tempTheValue);
				tempTheValue = static_cast<value>(TempInt) / 10000.0f;
				return tempTheValue;
}

void			MathClass::computeT1
(long double &x, long double &y)
{
	//Compute Theata 1 second
	long double numerator = LengthArm2 * sin(theata2);
	long double denominator = sqrt(pow(x, 2.0) + pow(y, 2.0));

	long double firstFractionTotal;
	firstFractionTotal = asin(numerator / denominator);

	long double secondFractionTotal;
	secondFractionTotal = atan(y / x);

	//Set Theata 1			
	theata1 = firstFractionTotal + secondFractionTotal;
}

void			MathClass::computeT2
(long double &x, long double &y) {
	//Compute Theata 2 first

	//Calculate numerator first...
	long double numerator;
	numerator = pow(x, 2.0) + pow(y, 2.0)
		- pow(LengthArm1, 2.0) - pow(LengthArm2, 2.0);

	//Calculate the denominator...
	long double denominator;
	denominator = 2 * LengthArm1 * LengthArm2;

	//Numerator over denominator... set T2
	theata2 = acos(numerator / denominator);
}
