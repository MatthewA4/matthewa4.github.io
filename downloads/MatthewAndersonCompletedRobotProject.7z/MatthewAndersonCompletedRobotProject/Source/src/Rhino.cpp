//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

//COMSC11 Robot Project

#include "Rhino.hpp"
#include <string>
using namespace std;

long Rhino::DMotorClickCount = 0;
long Rhino::EMotorClickCount = 0;

long Rhino::DMotorPreviousCount = 750;
long Rhino::EMotorPreviousCount = 750;

//Switch Status member function.
//******************************
char				Rhino::getSwitchPosStatus
(char sendChar) {
	char ToSend[] = "I";
	*theConnection << ToSend;
	Sleep(10);
	sendChar = sendChar & 0xDF;
	char Tmotor = sendChar - 'C';
	Tmotor = pow(2, Tmotor);

	char temp = { 0 };
	*theConnection >> temp;
	return  (temp - 32) & Tmotor;
}


//Motor Status member function.
//*****************************
char				Rhino::getMotorPosStatus
(const char motor) {
	char tempSwitch[3] = { 0 };
	tempSwitch[0] = motor;
	tempSwitch[1] = '?';
	*theConnection << tempSwitch;
	Sleep(10);
	char receive;

	*theConnection >> receive;
	
	return (receive - 32);
}

void				Rhino::wait(char motor)
{
	Sleep(20);
	while (Rhino::getMotorPosStatus(motor))
	{
		Sleep(20);
	}
}

//Move Function.
//**************
void				Rhino::Move
(long double x, long double y, long double r) {
	theMath->compute(x, y);
	//compute the angles

	//Convert the angles to tick count for the position needed to be moved too.
	DMotorClickCount = (theMath->getT2() / 0.12);
	EMotorClickCount = (theMath->getT1() / 0.12);

	//Figure out how many ticks needed to move +/-
	long DMoveAmount = DMotorPreviousCount - DMotorClickCount;
	long EMoveAmount = EMotorPreviousCount - EMotorClickCount;

	DMotorPreviousCount -= DMoveAmount;
	EMotorPreviousCount -= EMoveAmount;

	//Figure out how many "1" loops needed in the main move sequence
	int NumberOfLoopsArm1 = abs(EMoveAmount);
	int NumberOfLoopsArm2 = abs(DMoveAmount);

	//Make the connection
	theConnection->connect(Port, 9600, spEVEN);

	bool moving = true;

	//*********************************************************
	//Primary movement loop
	//*********************************************************
	while (moving)
	{
		Sleep(15);
		if (NumberOfLoopsArm1 > 0)
		{
			Sleep(15);
			if (EMoveAmount < 0)
			{
				*theConnection << "E-1";
				wait('E');
				*theConnection << "D+1";
				wait('D');
				Sleep(15);
			}
			if (EMoveAmount > 0)
			{
				*theConnection << "E+1";
				wait('E');
				*theConnection << "D-1";
				wait('D');
				Sleep(15);
			}
			Sleep(10);
		}
		if (NumberOfLoopsArm2 > 0)
		{
			Sleep(15);
			if (DMoveAmount > 0)
			{
				*theConnection << "D+1";
				wait('D');
			}
		}
		Sleep(10);
		if (DMoveAmount < 0)
		{
			*theConnection << "D-1";
			wait('D');
		}
		Sleep(10);
		if (NumberOfLoopsArm2 != 0) NumberOfLoopsArm2--;
		if (NumberOfLoopsArm1 != 0) NumberOfLoopsArm1--;
		if ((NumberOfLoopsArm1 == 0) && (NumberOfLoopsArm2 == 0)) moving = false;
	}
	theConnection->disconnect();
}


//Home function.
//**************
void				Rhino::goHome
() {
	theConnection->connect(Port, 9600, spEVEN);
	if((DMotorPreviousCount <= 750) && (EMotorPreviousCount >= 750))
	{
	while (this->getSwitchPosStatus('E'))
	{
		Sleep(15);
		*theConnection << "E-5";
		wait('E');
	}
	Sleep(15);
	while (this->getSwitchPosStatus('D'))
	{
		Sleep(15);
		*theConnection << "D+5";
		wait('E');
	}
}
	else
	{
		Move(9.0, 9.0);		//else, move to (9, 9)
	}
	theConnection->disconnect();
}


void Rhino::EngraveOn()
{
	Sleep(15);
	if (isEngraving == false)
	{
		theConnection->connect(Port, 9600, spEVEN);

		*theConnection << "F+90";
		wait('F');
		isEngraving = true;
		theConnection->disconnect();
	}
	Sleep(5);
}

void Rhino::EngraveOff()
{
	Sleep(15);
	if (isEngraving)
	{
		theConnection->connect(Port, 9600, spEVEN);
		*theConnection << "F-90";
		wait('F');
		isEngraving = false;
		theConnection->disconnect();
	}
	Sleep(5);
}