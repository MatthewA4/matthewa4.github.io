//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

#include "RoboBase.hpp"
#include <iostream>
#include "windows.h"
using namespace std;

void RoboBase::LineMove(Values * startPoint, Values * endPoint)
{
	LineClassV3 theLine;
	theLine.setLength(startPoint, endPoint);
	long double numsegments = theLine.getNumSegments();
	theLine.findslope();

	long double howfaralong = 1;
	Values *theValues;

	for (;howfaralong <= numsegments; howfaralong++)
	{
		 theValues = theLine.getXY(
			startPoint,
			howfaralong
		 );
		
		 Move(theValues->x, theValues->y);
		 delete[] theValues;
		 theValues = nullptr;
	}

}

void RoboBase::CircleMove(long double radius, Values* startPoint, long double arcAngle = 180)
{
	Move(startPoint->x, startPoint->y);
	CircleClassV2 theCircle;
	theCircle.setRadius(radius);
	theCircle.computeDT(0, arcAngle);
	theCircle.setCenterpoint(startPoint);
	long double numsegments = theCircle.getNumberSegments();
	Values *theValues;
	for (int steps = 1; steps <= numsegments; steps++)
	{
		theValues = theCircle.getXY(steps, 0);
		cout << "X:\t" << theValues->x << "\tY:\t" << theValues->y << endl;
		Move(theValues->x, theValues->y);
		delete[] theValues;
		theValues = nullptr;
	}
}

void RoboBase::DrawImage(char* filename, Values* Current, Values* startPoint)
{
	setFile(filename, Current);
	long long numberSteps = getNumberInstructions();
	for (long long step = 1; step <= numberSteps; step++)
	{
		getCommand(step);
			if ((getOperationMode() & CAN_MOVE) != 0)
			{
				if ((getOperationMode() & ENGRAVE_ON) != 0)
				{
					EngraveOn();
					incNumMovements(1);
				}
				else if ((getOperationMode() & ENGRAVE_OFF) != 0)
				{
					EngraveOff();
					incNumMovements(1);
				}

				if ((getOperationMode() & GO_HOME) != 0)
				{
					EngraveOff();
					goHome();
					incNumMovements(2);
					continue;
				}
				else if((getOperationMode() & RAPID_MOVE) != 0)
				{
					long feedspeed = getFeedSpeed();
					float rate = 1 / feedspeed;
					_sleep(rate * 30.0f);
					cout << getOperationStatus() << endl;
					Move(Current->x, Current->y, 0);
					startPoint->x = Current->x;
					startPoint->y = Current->y;
					startPoint->r = Current->r;
					incNumMovements(1); 
				}
				else if ((getOperationMode() & LINEAR_CUTTING_MOVE) != 0)
				{
					long feedspeed = getFeedSpeed();
					long rate = 1 / feedspeed;
					_sleep(rate * 30);
					cout << getOperationStatus() << endl;
					LineMove(startPoint, Current);
					startPoint->x = Current->x;
					startPoint->y = Current->y;
					startPoint->r = Current->r;
				}
			}
	}
}