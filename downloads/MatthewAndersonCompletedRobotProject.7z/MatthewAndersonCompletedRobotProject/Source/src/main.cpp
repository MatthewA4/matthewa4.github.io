//Copyright (C) 2017 Matthew R. Anderson
//All Rights Reserved.

//COMSC11 Robot project

#include "Rhino.hpp"
#include "MathClass.hpp"
#include "tserial.h"
#include <iostream>
#include <conio.h>
#include <cstdlib>
#include <stdio.h>
#include <inttypes.h>
#include <string>
using namespace std;

int main()
{
	//*************************************************************
	//*************************************************************

	//Author: Matthew R. Anderson
	
	//*************************************************************
	//*************************************************************


	//console setup
	//COM port selection
	int8_t EnterPort;
	char Comstring[5] = "COM";
	cout << "Enter Port:\t"; cin >> EnterPort;
	cin.ignore();
	Comstring[3] = EnterPort;

	//specify lengths and initial home position

	long double arm1, arm2;

	long double XHome, YHome, ZHome = 0;

	arm1 = 9; arm2 = 9; 
	XHome = YHome = 9.0; ZHome = 0;
	

	//RS-232 connection setup
	Tserial theConnection;
	
	Values Current, Point1, Point2;
	Current = { 0, };
	Point1 = { 0, };
	Point2 = { 0, };

	MathClass theMath(arm1, arm2);
	RoboBase *theRobotSelected;
	Rhino theRhino(&theConnection, &theMath, Comstring);
	theRobotSelected = &theRhino;
	//***************************************************

	//What to do with Robot
	char CommandEnter;
	//H for Home, M for Move to point, E for Exit

	cout << "Enter Command (H)ome, (M)ove, (L)ine Move, (C)ircle Move, (F)ile, (E)xit" << endl;
	CommandEnter = _getch();
	while (CommandEnter != 'E' && CommandEnter != 'e')
	{
		if (CommandEnter == 'H' || CommandEnter == 'h')
		{
			system("cls");
			cout << "Homing..." << endl;
			theRobotSelected->goHome();
			theRobotSelected->incNumMovements(1);
		}

		//If user wants to move.
		else if (CommandEnter == 'M' || CommandEnter == 'm')
		{
			system("cls");
			cout << "Move to X:\t"; cin >> Current.x;
			cin.ignore();
			cout << "Move to Y:\t"; cin >> Current.y;
			cin.ignore();

			cout << "Move to R:\t"; cin >> Current.r;
			cin.ignore();

			theRobotSelected->Move(Current.x, Current.y);
			cout << "[+] Moved " << theRobotSelected->getName() 
				<< " to specified point..." << endl;
			theRobotSelected->incNumMovements(1);
		}

		//LineMove
		else if (CommandEnter == 'L' || CommandEnter == 'l')
		{
			system("cls");
			cout << "Starting point (X):\t"; cin >> Point1.x;
			cin.ignore();
			cout << "Starting point (Y):\t"; cin >> Point1.y;
			cin.ignore();

			cout << "Starting point (R):\t"; cin >> Point1.r;
			cin.ignore();

			cout << "End point (X):\t"; cin >> Current.x;
			cin.ignore();
			cout << "End point (Y):\t"; cin >> Current.y;
			cin.ignore();
			cout << "End point (R):\t"; cin >> Current.r;
			cin.ignore();

			theRobotSelected->LineMove(&Point1, &Current);
			cout << theRobotSelected->getName() << 
				" robot Line Moved to position." << endl;
		}

		//G Code Parsing
		if (CommandEnter == 'f' || CommandEnter == 'F')
		{
			system("cls");
			Point1 = { XHome, YHome, ZHome, 0, 0 };

			char filename[32] = { 0, };
			cout << "Filename:\t"; cin >> filename;
			cin.ignore();
			theRobotSelected->DrawImage(filename, &Current, &Point1);
		}
		if (CommandEnter == 'C' || CommandEnter == 'c')
		{
			system("cls");
			long double radius, arch;
			cout << "Radius:\t"; cin >> radius;
			cout << "\n\nSTART POINT (NOT CENTER POINT!)" << endl;
			cout << "X:\t"; cin >> Point1.x;
			cout << "Y:\t"; cin >> Point1.y;
			cout << "Arch Angle:\t"; cin >> arch;

			theRobotSelected->CircleMove(radius, &Point1, arch);
		}
		system("cls");
		cout << "Enter second command:\t";  CommandEnter = _getch();
	}
	cout << "\nThe " << theRobotSelected->getName() << " robot moved "
		<< theRobotSelected->getNumMovements() << " times." << endl;
	system("pause");
	return 0;
}